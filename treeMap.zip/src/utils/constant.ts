export const MOBILE_WIDTH = '768px'
export const MAX_NAME_LENGTH = 50
export const MAX_TREE_MAP_LENGTH = 50
