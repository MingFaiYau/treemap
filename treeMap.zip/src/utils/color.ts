export default {
  appBodyBG: 'antiquewhite',
  removeButtonBG: 'red',
  treeMapBG: '#d3d3d3',
  treeItemBorder: 'black',
  treeItemPositiveBG: 'limegreen',
  treeItemNegativeBG: 'orangered',
}
